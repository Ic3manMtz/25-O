## HazClasificacion

Este proyecto toma un modelo ya hecho y clasifica el conjunto de entrenamiento con el modelo dado.

